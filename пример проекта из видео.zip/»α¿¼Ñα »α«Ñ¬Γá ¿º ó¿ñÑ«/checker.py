import module_by_gostmi as roblox

cookie = 'ccokie:)'
valid_check = roblox.valid_cookie_check(cookie)
if valid_check == 'valid':
    userid = roblox.account.get_user_id(cookie)
    print("Userid: ", userid)
    balance = roblox.account.get_balance(cookie, userid)
    print("Balance: ", balance)
    donate = roblox.account.get_account_donate(cookie, userid)
    print("Donate: ", donate)
    friend_count = roblox.account.get_friends_count(cookie)
    print("Friends: ", friend_count)
    rap = roblox.account.get_rap(cookie, userid)
    print('Rap: ', rap)